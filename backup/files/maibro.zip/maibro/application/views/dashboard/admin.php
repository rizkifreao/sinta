<section class="content-header">
    <h1>
        Dashboard
        <small></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
    </ol>
</section>

<section class="content">
    <div class="box">
        <div class="box-body">
            <h2>Selamat Datang Di Aplikasi Pelayanan Pengajuan Klaim Asuransi Jiwa Kredit</h2>
        </div>
    </div>
</section>